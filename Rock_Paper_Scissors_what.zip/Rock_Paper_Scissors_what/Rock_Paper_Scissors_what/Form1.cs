﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Rock_Paper_Scissors_what
{
    public partial class Form1 : Form
    {
        enum Weapons : int {Rock, Paper, Scissors, Lizard, Spock};
        Weapons userWeapon, comWeapon;
        string[] WORDARRAY = { "Who Shall Win?", "Are You Ready?"};
        Random rnd = new Random();
        int winCount = 0;
        int tiedCount = 0;
        int lostCount = 0;
        public object Me { get; private set; }

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void button2_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void radEasy_CheckedChanged(object sender, EventArgs e)
        {
            radRock.Enabled = true;
            radPaper.Enabled = true;
            radScissors.Enabled = true;
            radLizard.Enabled = false;
            radSpock.Enabled = false;
            lblCondition.Text = WORDARRAY[0];
        }

        private void radHard_CheckedChanged(object sender, EventArgs e)
        {
            radLizard.Enabled = true;
            radSpock.Enabled = true;
            lblCondition.Text = WORDARRAY[0];
        }
        
        private void btnFight_Click(object sender, EventArgs e)
        {
            int comSelection = rnd.Next(0, 4);
            bool valid = true;
            while (valid)
            {
                switch (comSelection)
                {
                    case 0:
                        comWeapon = Weapons.Rock;
                        valid = false;
                        break;
                    case 1:
                        comWeapon = Weapons.Paper;
                        valid = false;
                        break;
                    case 2:
                        comWeapon = Weapons.Scissors;
                        valid = false;
                        break;
                    case 3:
                        comWeapon = Weapons.Lizard;
                        valid = false;
                        break;
                    case 4:
                        comWeapon = Weapons.Spock;
                        valid = false;
                        break;
                    default:
                        valid = true;
                        break;
                }
            }
            switch ((int)userWeapon)
            {
                case 0: //Rock
                    {
                        if ((int)comWeapon == 0)
                        {
                            lblCondition.Text = "Your weapons clashed..." + Environment.NewLine + " nothing happened!";
                            tiedCount += 1;
                            lblDisplayTied.Text = Convert.ToString(tiedCount);
                        }
                        else if ((int)comWeapon == 1)
                        {
                            lblCondition.Text = "You lost because" + Environment.NewLine + " Paper Covers Rock!";
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                        }
                        else if ((int)comWeapon == 2)
                        {
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                            lblCondition.Text = "You won because" + Environment.NewLine + " Rock Crushes Scissors!";
                        }
                        else if ((int)comWeapon == 3)
                        {
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                            lblCondition.Text = "You won because" + Environment.NewLine + " Rock Crushes Lizard!";
                        }
                        else
                        {
                            lblCondition.Text = "You lost because" + Environment.NewLine + " Spock Vaporizes Rock!";
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                        }
                        break;
                    }
                case 1: //Paper
                    {
                        if ((int)comWeapon == 0)
                        {
                            lblCondition.Text = "You won because" + Environment.NewLine + " Paper Covers Rock!";
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                        }
                        else if ((int)comWeapon == 1)
                        {
                            lblCondition.Text = "Your weapons clashed..." + Environment.NewLine + " Nothing happend.";
                            tiedCount += 1;
                            lblDisplayTied.Text = Convert.ToString(tiedCount);
                        }
                        else if ((int)comWeapon == 2)
                        {
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                            lblCondition.Text = "You lost because" + Environment.NewLine + " Rock Crushes Scissors!";
                        }
                        else if ((int)comWeapon == 3)
                        {
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                            lblCondition.Text = "You lost because" + Environment.NewLine + " Lizard Eats Paper!";
                        }
                        else
                        {
                            lblCondition.Text = "You won because" + Environment.NewLine + " Paper Disproves Spock!";
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                        }
                        break;
                    }
                case 2://Scissors
                    {
                        if ((int)comWeapon == 0)
                        {
                            lblCondition.Text = "You lost because"+ Environment.NewLine + " Rock Crushed Scissor!";
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                        }
                        else if ((int)comWeapon == 1)
                        {
                            lblCondition.Text = "You won because" + Environment.NewLine + " Scissors Cuts Paper!";
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                        }
                        else if ((int)comWeapon == 2)
                        {
                            tiedCount += 1;
                            lblDisplayTied.Text = Convert.ToString(tiedCount);
                            lblCondition.Text = "Your weapons clash..." + Environment.NewLine + " Nothing Happend!";
                        }
                        else if ((int)comWeapon == 3)
                        {
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                            lblCondition.Text = "You won because" + Environment.NewLine + " Scissors decapitates Lizard!";
                        }
                        else
                        {
                            lblCondition.Text = "You lost because" + Environment.NewLine + " Spock Smashed Scissors!";
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                        }
                        break;
                    }
                case 3://Lizard
                    {
                        if ((int)comWeapon == 0)
                        {
                            lblCondition.Text = "You lost because" + Environment.NewLine + " Rock Crushed Lizard!";
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                        }
                        else if ((int)comWeapon == 1)
                        {
                            lblCondition.Text = "You won because" + Environment.NewLine + " Lizard eats Paper!";
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                        }
                        else if ((int)comWeapon == 2)
                        {
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                            lblCondition.Text = "You lost because" + Environment.NewLine + " Scissors decapitates Lizards!";
                        }
                        else if ((int)comWeapon == 3)
                        {
                            tiedCount += 1;
                            lblDisplayTied.Text = Convert.ToString(tiedCount);
                            lblCondition.Text = "Your weapons clashed..." +Environment.NewLine + " Nothing happenned!";
                        }
                        else
                        {
                            lblCondition.Text = "You won because" + Environment.NewLine + " Lizard Poisons Spock!";
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                        }
                        break;
                    }
                case 4://Spock
                    {
                        if ((int)comWeapon == 0)
                        {
                            lblCondition.Text = "You won because" + Environment.NewLine + " Spock Vaporizes Rock!";
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                        }
                        else if ((int)comWeapon == 1)
                        {
                            lblCondition.Text = "You lose because" + Environment.NewLine + " Paper disproves Spock!";
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                        }
                        else if ((int)comWeapon == 2)
                        {
                            winCount += 1;
                            lblDisplayWin.Text = Convert.ToString(winCount);
                            lblCondition.Text = "You win because" + Environment.NewLine + " Spock Smashed Scissors!";
                        }
                        else if ((int)comWeapon == 3)
                        {
                            lostCount += 1;
                            lblDisplayLoss.Text = Convert.ToString(lostCount);
                            lblCondition.Text = "You lost because" + Environment.NewLine + " Lizard Poisons Spock!";
                        }
                        else
                        {
                            lblCondition.Text = "You won because" + Environment.NewLine + " Lizard Poisons Spock!";
                            tiedCount += 1;
                            lblDisplayTied.Text = Convert.ToString(tiedCount);
                        }
                        break;
                    }
                default:
                    valid = false;
                    break;
            }
        }
        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void radRock_CheckedChanged(object sender, EventArgs e)
        {
            lblCondition.Text = WORDARRAY[1];
            userWeapon = Weapons.Rock;
        }

        private void radPaper_CheckedChanged(object sender, EventArgs e)
        {
            lblCondition.Text = WORDARRAY[1];
            userWeapon = Weapons.Paper;
        }

        private void radScissors_CheckedChanged(object sender, EventArgs e)
        {
            lblCondition.Text = WORDARRAY[1];
            userWeapon = Weapons.Scissors;
        }

        private void radLizard_CheckedChanged(object sender, EventArgs e)
        {
            lblCondition.Text = WORDARRAY[1];
            userWeapon = Weapons.Lizard;
        }

        private void radSpock_CheckedChanged(object sender, EventArgs e)
        {
            lblCondition.Text = WORDARRAY[1];
            userWeapon = Weapons.Spock;
        }
    }
}
