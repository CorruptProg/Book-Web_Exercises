﻿namespace Rock_Paper_Scissors_what
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.radEasy = new System.Windows.Forms.RadioButton();
            this.radHard = new System.Windows.Forms.RadioButton();
            this.radRock = new System.Windows.Forms.RadioButton();
            this.radSpock = new System.Windows.Forms.RadioButton();
            this.radLizard = new System.Windows.Forms.RadioButton();
            this.radScissors = new System.Windows.Forms.RadioButton();
            this.radPaper = new System.Windows.Forms.RadioButton();
            this.lblWin = new System.Windows.Forms.Label();
            this.lblLoss = new System.Windows.Forms.Label();
            this.lblTies = new System.Windows.Forms.Label();
            this.lblCondition = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.Statistics = new System.Windows.Forms.GroupBox();
            this.lblDisplayTied = new System.Windows.Forms.Label();
            this.lblDisplayLoss = new System.Windows.Forms.Label();
            this.lblDisplayWin = new System.Windows.Forms.Label();
            this.btnFight = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.Statistics.SuspendLayout();
            this.SuspendLayout();
            // 
            // radEasy
            // 
            this.radEasy.AutoSize = true;
            this.radEasy.BackgroundImageLayout = System.Windows.Forms.ImageLayout.None;
            this.radEasy.Location = new System.Drawing.Point(6, 19);
            this.radEasy.Name = "radEasy";
            this.radEasy.Size = new System.Drawing.Size(48, 17);
            this.radEasy.TabIndex = 0;
            this.radEasy.TabStop = true;
            this.radEasy.Text = "Easy";
            this.radEasy.UseVisualStyleBackColor = true;
            this.radEasy.CheckedChanged += new System.EventHandler(this.radEasy_CheckedChanged);
            // 
            // radHard
            // 
            this.radHard.Location = new System.Drawing.Point(128, 19);
            this.radHard.Name = "radHard";
            this.radHard.Size = new System.Drawing.Size(48, 17);
            this.radHard.TabIndex = 2;
            this.radHard.TabStop = true;
            this.radHard.Text = "Hard";
            this.radHard.UseVisualStyleBackColor = true;
            this.radHard.CheckedChanged += new System.EventHandler(this.radHard_CheckedChanged);
            // 
            // radRock
            // 
            this.radRock.AutoSize = true;
            this.radRock.Enabled = false;
            this.radRock.Location = new System.Drawing.Point(6, 19);
            this.radRock.Name = "radRock";
            this.radRock.Size = new System.Drawing.Size(51, 17);
            this.radRock.TabIndex = 3;
            this.radRock.TabStop = true;
            this.radRock.Text = "Rock";
            this.radRock.UseVisualStyleBackColor = true;
            this.radRock.CheckedChanged += new System.EventHandler(this.radRock_CheckedChanged);
            // 
            // radSpock
            // 
            this.radSpock.AutoSize = true;
            this.radSpock.Enabled = false;
            this.radSpock.Location = new System.Drawing.Point(65, 42);
            this.radSpock.Name = "radSpock";
            this.radSpock.Size = new System.Drawing.Size(56, 17);
            this.radSpock.TabIndex = 4;
            this.radSpock.TabStop = true;
            this.radSpock.Text = "Spock";
            this.radSpock.UseVisualStyleBackColor = true;
            this.radSpock.CheckedChanged += new System.EventHandler(this.radSpock_CheckedChanged);
            // 
            // radLizard
            // 
            this.radLizard.AutoSize = true;
            this.radLizard.Enabled = false;
            this.radLizard.Location = new System.Drawing.Point(63, 19);
            this.radLizard.Name = "radLizard";
            this.radLizard.Size = new System.Drawing.Size(53, 17);
            this.radLizard.TabIndex = 5;
            this.radLizard.TabStop = true;
            this.radLizard.Text = "Lizard";
            this.radLizard.UseVisualStyleBackColor = true;
            this.radLizard.CheckedChanged += new System.EventHandler(this.radLizard_CheckedChanged);
            // 
            // radScissors
            // 
            this.radScissors.AutoSize = true;
            this.radScissors.Enabled = false;
            this.radScissors.Location = new System.Drawing.Point(6, 65);
            this.radScissors.Name = "radScissors";
            this.radScissors.Size = new System.Drawing.Size(64, 17);
            this.radScissors.TabIndex = 6;
            this.radScissors.TabStop = true;
            this.radScissors.Text = "Scissors";
            this.radScissors.UseVisualStyleBackColor = true;
            this.radScissors.CheckedChanged += new System.EventHandler(this.radScissors_CheckedChanged);
            // 
            // radPaper
            // 
            this.radPaper.AutoSize = true;
            this.radPaper.Enabled = false;
            this.radPaper.Location = new System.Drawing.Point(6, 42);
            this.radPaper.Name = "radPaper";
            this.radPaper.Size = new System.Drawing.Size(53, 17);
            this.radPaper.TabIndex = 7;
            this.radPaper.TabStop = true;
            this.radPaper.Text = "Paper";
            this.radPaper.UseVisualStyleBackColor = true;
            this.radPaper.CheckedChanged += new System.EventHandler(this.radPaper_CheckedChanged);
            // 
            // lblWin
            // 
            this.lblWin.AutoSize = true;
            this.lblWin.Location = new System.Drawing.Point(6, 56);
            this.lblWin.Name = "lblWin";
            this.lblWin.Size = new System.Drawing.Size(29, 13);
            this.lblWin.TabIndex = 9;
            this.lblWin.Text = "Win:";
            // 
            // lblLoss
            // 
            this.lblLoss.AutoSize = true;
            this.lblLoss.Location = new System.Drawing.Point(3, 89);
            this.lblLoss.Name = "lblLoss";
            this.lblLoss.Size = new System.Drawing.Size(32, 13);
            this.lblLoss.TabIndex = 10;
            this.lblLoss.Text = "Loss:";
            // 
            // lblTies
            // 
            this.lblTies.AutoSize = true;
            this.lblTies.Location = new System.Drawing.Point(3, 123);
            this.lblTies.Name = "lblTies";
            this.lblTies.Size = new System.Drawing.Size(30, 13);
            this.lblTies.TabIndex = 11;
            this.lblTies.Text = "Ties:";
            // 
            // lblCondition
            // 
            this.lblCondition.AutoSize = true;
            this.lblCondition.Font = new System.Drawing.Font("Microsoft Sans Serif", 6.5F);
            this.lblCondition.Location = new System.Drawing.Point(6, 23);
            this.lblCondition.Name = "lblCondition";
            this.lblCondition.Size = new System.Drawing.Size(69, 12);
            this.lblCondition.TabIndex = 12;
            this.lblCondition.Text = "Who Shall Win?";
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.radEasy);
            this.groupBox1.Controls.Add(this.radHard);
            this.groupBox1.Location = new System.Drawing.Point(12, 12);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(182, 61);
            this.groupBox1.TabIndex = 13;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Choose Your Difficulty!!!";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.radRock);
            this.groupBox2.Controls.Add(this.radPaper);
            this.groupBox2.Controls.Add(this.radScissors);
            this.groupBox2.Controls.Add(this.radLizard);
            this.groupBox2.Controls.Add(this.radSpock);
            this.groupBox2.Location = new System.Drawing.Point(12, 68);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(182, 89);
            this.groupBox2.TabIndex = 14;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Choose Your Weapon!!!";
            // 
            // Statistics
            // 
            this.Statistics.Controls.Add(this.lblDisplayTied);
            this.Statistics.Controls.Add(this.lblDisplayLoss);
            this.Statistics.Controls.Add(this.lblDisplayWin);
            this.Statistics.Controls.Add(this.lblWin);
            this.Statistics.Controls.Add(this.lblLoss);
            this.Statistics.Controls.Add(this.lblTies);
            this.Statistics.Controls.Add(this.lblCondition);
            this.Statistics.Location = new System.Drawing.Point(194, 12);
            this.Statistics.Name = "Statistics";
            this.Statistics.Size = new System.Drawing.Size(136, 145);
            this.Statistics.TabIndex = 15;
            this.Statistics.TabStop = false;
            this.Statistics.Text = "Statistics";
            // 
            // lblDisplayTied
            // 
            this.lblDisplayTied.AutoSize = true;
            this.lblDisplayTied.Location = new System.Drawing.Point(41, 123);
            this.lblDisplayTied.Name = "lblDisplayTied";
            this.lblDisplayTied.Size = new System.Drawing.Size(13, 13);
            this.lblDisplayTied.TabIndex = 15;
            this.lblDisplayTied.Text = "0";
            // 
            // lblDisplayLoss
            // 
            this.lblDisplayLoss.AutoSize = true;
            this.lblDisplayLoss.Location = new System.Drawing.Point(41, 89);
            this.lblDisplayLoss.Name = "lblDisplayLoss";
            this.lblDisplayLoss.Size = new System.Drawing.Size(13, 13);
            this.lblDisplayLoss.TabIndex = 14;
            this.lblDisplayLoss.Text = "0";
            // 
            // lblDisplayWin
            // 
            this.lblDisplayWin.AutoSize = true;
            this.lblDisplayWin.Location = new System.Drawing.Point(41, 56);
            this.lblDisplayWin.Name = "lblDisplayWin";
            this.lblDisplayWin.Size = new System.Drawing.Size(13, 13);
            this.lblDisplayWin.TabIndex = 13;
            this.lblDisplayWin.Text = "0";
            this.lblDisplayWin.Click += new System.EventHandler(this.label1_Click);
            // 
            // btnFight
            // 
            this.btnFight.Location = new System.Drawing.Point(12, 163);
            this.btnFight.Name = "btnFight";
            this.btnFight.Size = new System.Drawing.Size(75, 25);
            this.btnFight.TabIndex = 16;
            this.btnFight.Text = "Fight";
            this.btnFight.UseVisualStyleBackColor = true;
            this.btnFight.Click += new System.EventHandler(this.btnFight_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(255, 163);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 17;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.button2_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(336, 193);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnFight);
            this.Controls.Add(this.Statistics);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Name = "Form1";
            this.Text = "Rock, Paper, Spock!!!";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.Statistics.ResumeLayout(false);
            this.Statistics.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.RadioButton radEasy;
        private System.Windows.Forms.RadioButton radHard;
        private System.Windows.Forms.RadioButton radRock;
        private System.Windows.Forms.RadioButton radSpock;
        private System.Windows.Forms.RadioButton radLizard;
        private System.Windows.Forms.RadioButton radScissors;
        private System.Windows.Forms.RadioButton radPaper;
        private System.Windows.Forms.Label lblWin;
        private System.Windows.Forms.Label lblLoss;
        private System.Windows.Forms.Label lblTies;
        private System.Windows.Forms.Label lblCondition;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.GroupBox Statistics;
        private System.Windows.Forms.Button btnFight;
        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.Label lblDisplayWin;
        private System.Windows.Forms.Label lblDisplayTied;
        private System.Windows.Forms.Label lblDisplayLoss;
    }
}

