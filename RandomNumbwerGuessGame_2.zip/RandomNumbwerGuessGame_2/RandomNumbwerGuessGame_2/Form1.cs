﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace RandomNumbwerGuessGame_2
{
    public partial class Form1 : Form
    {
        Random rnd = new Random();
        int comNum = 0;
        int winCount = 0;
        int loseCount = 0;
        int guessCount = 10;
        public Form1()
        {
            InitializeComponent();
        }

        private void radEasy_CheckedChanged(object sender, EventArgs e)
        {
            if (radEasy.Checked)
            {
                comNum = rnd.Next(1, 100);
                lblInstruction.Text = "With Easy difficulty, the number" + Environment.NewLine + " will be between 1 and 100. You have Ten(10) guesses. Guess Away.";
                mskUserGuess.Mask = "000";
            }
        }

        private void radMedium_CheckedChanged(object sender, EventArgs e)
        {
            if (radMedium.Checked)
            {
                comNum = rnd.Next(1, 1000);
                lblInstruction.Text = "With Medium difficulty, the number" + Environment.NewLine + " will be between 1 and 1000. You have Ten(10) guesses. Guess Away.";
                mskUserGuess.Mask = "0000";
            }
        }

        private void radHard_CheckedChanged(object sender, EventArgs e)
        {
            if (radHard.Checked)
            {
                comNum = rnd.Next(1, 10000);
                lblInstruction.Text = "With Hard difficulty, the number" + Environment.NewLine + " will be between 1 and 10000. You have Ten(10) guesses. Guess Away.";
                mskUserGuess.Mask = "00000";
            }
        }

        private void mskUserGuess_Click(object sender, EventArgs e)
        {
            mskUserGuess.SelectAll();
        }

        private void btnReady_Click(object sender, EventArgs e)
        {
            mskUserGuess.Visible = true;
            gpbDifficult.Enabled = false;
            btnGuess.Visible = true;
            grpConditions.Visible = true;
            btnAgain.Enabled = true;
            lblHint.Text = "HINT";
        }

        private void btnGuess_Click(object sender, EventArgs e)
        {
            lblHint.Visible = true;
            int userGuess = Convert.ToInt32(mskUserGuess.Text);
                if (userGuess != comNum)
                {
                    if (userGuess > comNum)
                    {
                        if (guessCount == 0)
                        {
                            lblHint.Text = "You lose. The number was " + comNum + ".";
                            loseCount += 1;
                            mskUserGuess.Enabled = false;
                            btnGuess.Enabled = false;
                            lblDisplayLose.Text = Convert.ToString(loseCount);
                        }
                        else
                        {
                            lblHint.Text = "Too High.";
                            mskUserGuess.Focus();
                            guessCount--;
                        }
                    }
                    else
                    {
                        if (guessCount == 0)
                        {
                            lblHint.Text = "You lose. The number was " + comNum + ".";
                            loseCount += 1;
                            mskUserGuess.Enabled = false;
                            btnGuess.Enabled = false;
                            lblDisplayLose.Text = Convert.ToString(loseCount);
                        }
                        else
                        {
                            lblHint.Text = "Too low.";
                            mskUserGuess.Focus();
                            guessCount--;
                        }
                    }
                }
                else
                {
                    lblHint.Text = "You win!!";
                    winCount += 1;
                    lblDisplayWin.Text = Convert.ToString(winCount);
                }
        }

        private void btnAgain_Click(object sender, EventArgs e)
        {
            gpbDifficult.Enabled = true;
            btnGuess.Enabled = false;
            mskUserGuess.Enabled = false;
            btnAgain.Enabled = false;
        }
    }
}
