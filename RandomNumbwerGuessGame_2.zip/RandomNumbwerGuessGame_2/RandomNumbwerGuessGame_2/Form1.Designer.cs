﻿namespace RandomNumbwerGuessGame_2
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnReady = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.lblInstruction = new System.Windows.Forms.Label();
            this.mskUserGuess = new System.Windows.Forms.MaskedTextBox();
            this.gpbDifficult = new System.Windows.Forms.GroupBox();
            this.radHard = new System.Windows.Forms.RadioButton();
            this.radMedium = new System.Windows.Forms.RadioButton();
            this.radEasy = new System.Windows.Forms.RadioButton();
            this.btnGuess = new System.Windows.Forms.Button();
            this.lblHint = new System.Windows.Forms.Label();
            this.lblWin = new System.Windows.Forms.Label();
            this.lblLoss = new System.Windows.Forms.Label();
            this.grpConditions = new System.Windows.Forms.GroupBox();
            this.lblDisplayWin = new System.Windows.Forms.Label();
            this.lblDisplayLose = new System.Windows.Forms.Label();
            this.btnAgain = new System.Windows.Forms.Button();
            this.gpbDifficult.SuspendLayout();
            this.grpConditions.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnReady
            // 
            this.btnReady.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnReady.Location = new System.Drawing.Point(204, 42);
            this.btnReady.Name = "btnReady";
            this.btnReady.Size = new System.Drawing.Size(65, 23);
            this.btnReady.TabIndex = 11;
            this.btnReady.Text = "Ready?";
            this.btnReady.UseVisualStyleBackColor = true;
            this.btnReady.Click += new System.EventHandler(this.btnReady_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 9);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(120, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Choose A Difficult Level";
            // 
            // lblInstruction
            // 
            this.lblInstruction.AutoSize = true;
            this.lblInstruction.Location = new System.Drawing.Point(15, 72);
            this.lblInstruction.Name = "lblInstruction";
            this.lblInstruction.Size = new System.Drawing.Size(247, 13);
            this.lblInstruction.TabIndex = 10;
            this.lblInstruction.Text = "With easy difficulty, the number is between 1 - 100.";
            // 
            // mskUserGuess
            // 
            this.mskUserGuess.Location = new System.Drawing.Point(15, 111);
            this.mskUserGuess.Mask = "000";
            this.mskUserGuess.Name = "mskUserGuess";
            this.mskUserGuess.PromptChar = ' ';
            this.mskUserGuess.Size = new System.Drawing.Size(40, 20);
            this.mskUserGuess.TabIndex = 12;
            this.mskUserGuess.Visible = false;
            this.mskUserGuess.Click += new System.EventHandler(this.mskUserGuess_Click);
            // 
            // gpbDifficult
            // 
            this.gpbDifficult.Controls.Add(this.radHard);
            this.gpbDifficult.Controls.Add(this.radMedium);
            this.gpbDifficult.Controls.Add(this.radEasy);
            this.gpbDifficult.Location = new System.Drawing.Point(15, 25);
            this.gpbDifficult.Name = "gpbDifficult";
            this.gpbDifficult.Size = new System.Drawing.Size(182, 44);
            this.gpbDifficult.TabIndex = 9;
            this.gpbDifficult.TabStop = false;
            this.gpbDifficult.Text = "Difficulty Level";
            // 
            // radHard
            // 
            this.radHard.AutoSize = true;
            this.radHard.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radHard.Location = new System.Drawing.Point(129, 17);
            this.radHard.Name = "radHard";
            this.radHard.Size = new System.Drawing.Size(48, 17);
            this.radHard.TabIndex = 4;
            this.radHard.TabStop = true;
            this.radHard.Text = "Hard";
            this.radHard.UseVisualStyleBackColor = true;
            this.radHard.CheckedChanged += new System.EventHandler(this.radHard_CheckedChanged);
            // 
            // radMedium
            // 
            this.radMedium.AutoSize = true;
            this.radMedium.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radMedium.Location = new System.Drawing.Point(61, 17);
            this.radMedium.Name = "radMedium";
            this.radMedium.Size = new System.Drawing.Size(62, 17);
            this.radMedium.TabIndex = 3;
            this.radMedium.TabStop = true;
            this.radMedium.Text = "Medium";
            this.radMedium.UseVisualStyleBackColor = true;
            this.radMedium.CheckedChanged += new System.EventHandler(this.radMedium_CheckedChanged);
            // 
            // radEasy
            // 
            this.radEasy.AutoSize = true;
            this.radEasy.Cursor = System.Windows.Forms.Cursors.Hand;
            this.radEasy.Location = new System.Drawing.Point(7, 17);
            this.radEasy.Name = "radEasy";
            this.radEasy.Size = new System.Drawing.Size(48, 17);
            this.radEasy.TabIndex = 2;
            this.radEasy.TabStop = true;
            this.radEasy.Text = "Easy";
            this.radEasy.UseVisualStyleBackColor = true;
            this.radEasy.CheckedChanged += new System.EventHandler(this.radEasy_CheckedChanged);
            // 
            // btnGuess
            // 
            this.btnGuess.Cursor = System.Windows.Forms.Cursors.Hand;
            this.btnGuess.Location = new System.Drawing.Point(15, 137);
            this.btnGuess.Name = "btnGuess";
            this.btnGuess.Size = new System.Drawing.Size(75, 23);
            this.btnGuess.TabIndex = 13;
            this.btnGuess.Text = "Guess";
            this.btnGuess.UseVisualStyleBackColor = true;
            this.btnGuess.Visible = false;
            this.btnGuess.Click += new System.EventHandler(this.btnGuess_Click);
            // 
            // lblHint
            // 
            this.lblHint.AutoSize = true;
            this.lblHint.Location = new System.Drawing.Point(12, 165);
            this.lblHint.Name = "lblHint";
            this.lblHint.Size = new System.Drawing.Size(33, 13);
            this.lblHint.TabIndex = 14;
            this.lblHint.Text = "HINT";
            this.lblHint.Visible = false;
            // 
            // lblWin
            // 
            this.lblWin.AutoSize = true;
            this.lblWin.Location = new System.Drawing.Point(6, 16);
            this.lblWin.Name = "lblWin";
            this.lblWin.Size = new System.Drawing.Size(29, 13);
            this.lblWin.TabIndex = 15;
            this.lblWin.Text = "Win:";
            // 
            // lblLoss
            // 
            this.lblLoss.AutoSize = true;
            this.lblLoss.Location = new System.Drawing.Point(6, 33);
            this.lblLoss.Name = "lblLoss";
            this.lblLoss.Size = new System.Drawing.Size(33, 13);
            this.lblLoss.TabIndex = 16;
            this.lblLoss.Text = "Lose:";
            // 
            // grpConditions
            // 
            this.grpConditions.Controls.Add(this.lblDisplayLose);
            this.grpConditions.Controls.Add(this.lblDisplayWin);
            this.grpConditions.Controls.Add(this.lblWin);
            this.grpConditions.Controls.Add(this.lblLoss);
            this.grpConditions.Location = new System.Drawing.Point(192, 111);
            this.grpConditions.Name = "grpConditions";
            this.grpConditions.Size = new System.Drawing.Size(69, 67);
            this.grpConditions.TabIndex = 18;
            this.grpConditions.TabStop = false;
            this.grpConditions.Text = "Results";
            this.grpConditions.Visible = false;
            // 
            // lblDisplayWin
            // 
            this.lblDisplayWin.AutoSize = true;
            this.lblDisplayWin.Location = new System.Drawing.Point(41, 16);
            this.lblDisplayWin.Name = "lblDisplayWin";
            this.lblDisplayWin.Size = new System.Drawing.Size(13, 13);
            this.lblDisplayWin.TabIndex = 18;
            this.lblDisplayWin.Text = "0";
            // 
            // lblDisplayLose
            // 
            this.lblDisplayLose.AutoSize = true;
            this.lblDisplayLose.Location = new System.Drawing.Point(41, 33);
            this.lblDisplayLose.Name = "lblDisplayLose";
            this.lblDisplayLose.Size = new System.Drawing.Size(13, 13);
            this.lblDisplayLose.TabIndex = 19;
            this.lblDisplayLose.Text = "0";
            // 
            // btnAgain
            // 
            this.btnAgain.Location = new System.Drawing.Point(15, 186);
            this.btnAgain.Name = "btnAgain";
            this.btnAgain.Size = new System.Drawing.Size(75, 23);
            this.btnAgain.TabIndex = 19;
            this.btnAgain.Text = "Play Again?";
            this.btnAgain.UseVisualStyleBackColor = true;
            this.btnAgain.Click += new System.EventHandler(this.btnAgain_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(290, 221);
            this.Controls.Add(this.btnAgain);
            this.Controls.Add(this.grpConditions);
            this.Controls.Add(this.lblHint);
            this.Controls.Add(this.btnGuess);
            this.Controls.Add(this.btnReady);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblInstruction);
            this.Controls.Add(this.mskUserGuess);
            this.Controls.Add(this.gpbDifficult);
            this.Name = "Form1";
            this.Text = "RanNum Game";
            this.gpbDifficult.ResumeLayout(false);
            this.gpbDifficult.PerformLayout();
            this.grpConditions.ResumeLayout(false);
            this.grpConditions.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnReady;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblInstruction;
        private System.Windows.Forms.MaskedTextBox mskUserGuess;
        private System.Windows.Forms.GroupBox gpbDifficult;
        private System.Windows.Forms.RadioButton radHard;
        private System.Windows.Forms.RadioButton radMedium;
        private System.Windows.Forms.RadioButton radEasy;
        private System.Windows.Forms.Button btnGuess;
        private System.Windows.Forms.Label lblHint;
        private System.Windows.Forms.Label lblWin;
        private System.Windows.Forms.Label lblLoss;
        private System.Windows.Forms.GroupBox grpConditions;
        private System.Windows.Forms.Label lblDisplayLose;
        private System.Windows.Forms.Label lblDisplayWin;
        private System.Windows.Forms.Button btnAgain;
    }
}

